"""
Dream School mock exam boti — asosiy mantiq.
Telegram'ga bog'liq emas: baholash, mavzular tahlili, reyting va ma'lumotlar bazasi.
"""
import hashlib
import html
import random
import re
import sqlite3
from datetime import datetime

VALID = set("abcde")


# ---------- Javoblarni o'qish ----------

def parse_answers(text: str) -> str:
    """'abcd...' yoki '1a2b3c...' ko'rinishini 'abcd...' ga keltiradi."""
    t = re.sub(r"\s+", "", text.lower())
    if re.fullmatch(r"(\d+[a-e])+", t):
        pairs = re.findall(r"(\d+)([a-e])", t)
        n = max(int(i) for i, _ in pairs)
        out = ["-"] * n
        for i, a in pairs:
            out[int(i) - 1] = a
        return "".join(out)
    if re.fullmatch(r"[a-e]+", t):
        return t
    raise ValueError("Javoblar formati noto'g'ri")


def parse_submission(text: str):
    """'123456*abcd...' yoki '123456#1a2b...' -> (kod, javoblar). Mos kelmasa None."""
    m = re.fullmatch(r"\s*(\d{4,8})\s*[*#]\s*(.+?)\s*", text, re.S)
    if not m:
        return None
    return m.group(1), parse_answers(m.group(2))


def parse_topics(spec: str, n: int):
    """'1-10:Biologiya, 11-20:Kimyo, 21-30:Fizika' -> har bir savol uchun mavzu ro'yxati."""
    topics = [None] * n
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        m = re.fullmatch(r"(\d+)\s*-\s*(\d+)\s*:\s*(.+)", part)
        if not m:
            raise ValueError(f"Mavzu formati noto'g'ri: {part}")
        a, b, name = int(m.group(1)), int(m.group(2)), m.group(3).strip()
        if not (1 <= a <= b <= n):
            raise ValueError(f"Savol oralig'i noto'g'ri: {a}-{b} (jami {n} ta savol)")
        for i in range(a - 1, b):
            topics[i] = name
    missing = [str(i + 1) for i, t in enumerate(topics) if t is None]
    if missing:
        raise ValueError("Mavzusiz savollar: " + ", ".join(missing))
    return topics


# ---------- Baholash va tahlil ----------

def grade(key: str, answers: str):
    """Har bir savol uchun True/False ro'yxati."""
    return [i < len(answers) and answers[i] == k for i, k in enumerate(key)]


def topic_breakdown(topics, marks):
    """{mavzu: (to'g'ri, jami)} — mavzular kiritilgan tartibda."""
    res = {}
    for t, ok in zip(topics, marks):
        c, n = res.get(t, (0, 0))
        res[t] = (c + ok, n + 1)
    return res


def pct(c, n):
    return round(100 * c / n) if n else 0


# ---------- Ma'lumotlar bazasi ----------

class DB:
    def __init__(self, path="dreambot.db"):
        self.con = sqlite3.connect(path)
        self.con.row_factory = sqlite3.Row
        self.con.executescript(
            """
            CREATE TABLE IF NOT EXISTS students(
                user_id INTEGER PRIMARY KEY, name TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS tests(
                code TEXT PRIMARY KEY, title TEXT, key TEXT, topics TEXT,
                open INTEGER DEFAULT 1, created TEXT, kind TEXT DEFAULT 'mock');
            CREATE TABLE IF NOT EXISTS subs(
                code TEXT, user_id INTEGER, answers TEXT, score INTEGER, ts TEXT,
                PRIMARY KEY(code, user_id));
            """
        )
        cols = [r[1] for r in self.con.execute("PRAGMA table_info(tests)")]
        if "kind" not in cols:
            self.con.execute("ALTER TABLE tests ADD COLUMN kind TEXT DEFAULT 'mock'")
            self.con.commit()

    # O'quvchilar
    def set_name(self, uid, name):
        self.con.execute("INSERT OR REPLACE INTO students VALUES(?,?)", (uid, name))
        self.con.commit()

    def name(self, uid):
        r = self.con.execute("SELECT name FROM students WHERE user_id=?", (uid,)).fetchone()
        return r["name"] if r else None

    # Testlar
    def create_test(self, title, key, topics, kind="mock"):
        while True:
            code = str(random.randint(100000, 999999))
            if not self.test(code):
                break
        self.con.execute(
            "INSERT INTO tests(code,title,key,topics,created,kind) VALUES(?,?,?,?,?,?)",
            (code, title, key, "|".join(topics), datetime.now().isoformat(timespec="minutes"), kind),
        )
        self.con.commit()
        return code

    def test(self, code):
        r = self.con.execute("SELECT * FROM tests WHERE code=?", (code,)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["topics"] = d["topics"].split("|")
        return d

    def close_test(self, code):
        self.con.execute("UPDATE tests SET open=0 WHERE code=?", (code,))
        self.con.commit()

    def open_tests(self):
        return [dict(r) for r in self.con.execute(
            "SELECT code,title FROM tests WHERE open=1 ORDER BY created")]

    # Javoblar
    def submit(self, code, uid, answers):
        """Qaytaradi: 'ok' | 'no_test' | 'closed' | 'dup' | ('len', kerakli_son)."""
        t = self.test(code)
        if not t:
            return "no_test"
        if not t["open"]:
            return "closed"
        if len(answers) != len(t["key"]):
            return ("len", len(t["key"]))
        if self.con.execute("SELECT 1 FROM subs WHERE code=? AND user_id=?", (code, uid)).fetchone():
            return "dup"
        score = sum(grade(t["key"], answers))
        self.con.execute("INSERT INTO subs VALUES(?,?,?,?,?)",
                         (code, uid, answers, score, datetime.now().isoformat(timespec="seconds")))
        self.con.commit()
        return "ok"

    def subs(self, code):
        """Ball bo'yicha kamayish, teng bo'lsa — kim oldin topshirgan."""
        return [dict(r) for r in self.con.execute(
            """SELECT s.*, st.name FROM subs s LEFT JOIN students st USING(user_id)
               WHERE code=? ORDER BY score DESC, ts ASC""", (code,))]

    # Tahlil
    def test_report(self, code):
        t = self.test(code)
        rows = self.subs(code)
        n = len(t["key"])
        topic_tot = {}
        q_correct = [0] * n
        for r in rows:
            marks = grade(t["key"], r["answers"])
            r["marks"] = marks
            for i, ok in enumerate(marks):
                q_correct[i] += ok
            for tp, (c, m) in topic_breakdown(t["topics"], marks).items():
                a, b = topic_tot.get(tp, (0, 0))
                topic_tot[tp] = (a + c, b + m)
        return t, rows, topic_tot, q_correct

    def student_history(self, uid):
        """O'quvchining barcha yopilgan testlari: [(test, sub, {mavzu:(c,n)})]."""
        out = []
        for r in self.con.execute(
            """SELECT s.*, t.title, t.key, t.topics, t.kind FROM subs s JOIN tests t USING(code)
               WHERE s.user_id=? AND t.open=0 ORDER BY s.ts""", (uid,)):
            topics = r["topics"].split("|")
            out.append((dict(r), topic_breakdown(topics, grade(r["key"], r["answers"]))))
        return out

    def overall_rating(self, min_tests=1, kind=None):
        """Umumiy reyting: yopilgan testlardagi o'rtacha foiz."""
        rows = self.con.execute(
            """SELECT s.user_id, st.name, COUNT(*) AS cnt,
                      AVG(100.0 * s.score / LENGTH(t.key)) AS avg
               FROM subs s JOIN tests t USING(code) LEFT JOIN students st USING(user_id)
               WHERE t.open=0 AND (? IS NULL OR t.kind=?) GROUP BY s.user_id HAVING cnt>=?
               ORDER BY avg DESC, cnt DESC""", (kind, kind, min_tests))
        return [dict(r) for r in rows]

    def export_data(self):
        """Mini ilova uchun barcha yakunlangan natijalar (data.json)."""
        out = {"updated": datetime.now().strftime("%Y-%m-%d %H:%M"), "kinds": {}, "students": {}}
        for kind in KINDS:
            tests = []
            for (code,) in self.con.execute(
                    "SELECT code FROM tests WHERE open=0 AND kind=? ORDER BY created DESC", (kind,)).fetchall():
                t, rows, tt, _ = self.test_report(code)
                tests.append({
                    "title": t["title"], "date": (t["created"] or "")[:10], "n": len(t["key"]),
                    "topics": [[tp, pct(c, m)] for tp, (c, m) in tt.items()],
                    "results": [[r["name"] or "?", r["score"]] for r in rows],
                })
            out["kinds"][kind] = {
                "rating": [[r["name"] or "?", round(r["avg"]), r["cnt"]] for r in self.overall_rating(kind=kind)],
                "tests": tests,
            }
        uids = [r[0] for r in self.con.execute(
            "SELECT DISTINCT s.user_id FROM subs s JOIN tests t USING(code) WHERE t.open=0")]
        for uid in uids:
            hist = self.student_history(uid)
            agg = {}
            for _, br in hist:
                for tp, (c, m) in br.items():
                    a, b = agg.get(tp, (0, 0))
                    agg[tp] = (a + c, b + m)
            out["students"][student_hash(uid)] = {
                "name": self.name(uid) or "?",
                "tests": [[s["title"], s["kind"], s["score"], len(s["key"]), s["ts"][:10]] for s, _ in hist],
                "topics": sorted([[tp, pct(c, m)] for tp, (c, m) in agg.items()], key=lambda x: x[1]),
            }
        return out


KINDS = {"mock": "Mock exam", "mavzu": "Mavzulashgan test"}


def student_hash(uid):
    """O'quvchi ID raqami ochiq ko'rinmasligi uchun (mini ilova ham shunday hisoblaydi)."""
    return hashlib.sha256(f"sciencepro:{uid}".encode()).hexdigest()[:16]


# ---------- Matnlar ----------

MEDALS = ["🥇", "🥈", "🥉"]


def format_channel_report(t, rows, topic_tot, q_correct, top=30):
    n = len(t["key"])
    lines = [f"⛔️ <b>{html.escape(t['title'])}</b> yakunlandi", f"Test kodi: {t['code']} · Savollar: {n} ta",
             f"Qatnashchilar: {len(rows)} nafar", "", "✅ <b>Natijalar:</b>"]
    prev, place = None, 0
    for i, r in enumerate(rows[:top]):
        if r["score"] != prev:
            place, prev = i + 1, r["score"]
        medal = MEDALS[place - 1] if place <= 3 else ""
        lines.append(f"{place}. {html.escape(r['name'] or '?')} — {r['score']}/{n} {medal}".rstrip())
    if len(rows) > top:
        lines.append(f"… va yana {len(rows) - top} nafar")

    if rows:
        lines += ["", "📊 <b>Mavzular bo'yicha o'rtacha natija:</b>"]
        for tp, (c, m) in sorted(topic_tot.items(), key=lambda x: pct(*x[1])):
            lines.append(f"{bar(pct(c, m))} {pct(c, m)}% — {html.escape(tp)}")
        hard = sorted(range(n), key=lambda i: q_correct[i])[:5]
        lines += ["", "🔥 <b>Eng qiyin savollar:</b>"]
        for i in hard:
            lines.append(f"{i + 1}-savol ({html.escape(t['topics'][i])}) — {pct(q_correct[i], len(rows))}% to'g'ri")

    lines += ["", "🔑 <b>To'g'ri javoblar:</b>",
              "<code>" + "  ".join(f"{i + 1}.{k}" for i, k in enumerate(t["key"])) + "</code>"]
    return "\n".join(lines)


def format_personal_report(t, row, place, total):
    n = len(t["key"])
    lines = [f"📝 <b>{html.escape(t['title'])}</b> natijangiz", f"Ball: <b>{row['score']}/{n}</b> ({pct(row['score'], n)}%)",
             f"O'rin: {place}/{total}", "", "<b>Mavzular bo'yicha:</b>"]
    for tp, (c, m) in topic_breakdown(t["topics"], row["marks"]).items():
        lines.append(f"{bar(pct(c, m))} {c}/{m} — {html.escape(tp)}")
    wrong = [str(i + 1) for i, ok in enumerate(row["marks"]) if not ok]
    if wrong:
        lines += ["", "❌ Xato savollar: " + ", ".join(wrong)]
    weak = [tp for tp, (c, m) in topic_breakdown(t["topics"], row["marks"]).items() if pct(c, m) < 60]
    if weak:
        lines.append("📌 Ko'proq e'tibor bering: " + ", ".join(html.escape(w) for w in weak))
    return "\n".join(lines)


def format_history(name, hist):
    if not hist:
        return "Hali yakunlangan testlaringiz yo'q."
    lines = [f"📈 <b>{html.escape(name)}</b> — natijalar tarixi", ""]
    agg = {}
    for sub, br in hist:
        n = len(sub["key"])
        lines.append(f"• {html.escape(sub['title'])}: {sub['score']}/{n} ({pct(sub['score'], n)}%)")
        for tp, (c, m) in br.items():
            a, b = agg.get(tp, (0, 0))
            agg[tp] = (a + c, b + m)
    lines += ["", "<b>Barcha testlar bo'yicha mavzular:</b>"]
    for tp, (c, m) in sorted(agg.items(), key=lambda x: pct(*x[1])):
        lines.append(f"{bar(pct(c, m))} {pct(c, m)}% — {html.escape(tp)}")
    return "\n".join(lines)


def format_overall(rows, top=20):
    if not rows:
        return "Hali reyting uchun ma'lumot yo'q."
    lines = ["🏆 <b>Umumiy reyting</b> (barcha mock examlar bo'yicha o'rtacha)", ""]
    for i, r in enumerate(rows[:top]):
        medal = MEDALS[i] if i < 3 else ""
        lines.append(f"{i + 1}. {html.escape(r['name'] or '?')} — {round(r['avg'])}% ({r['cnt']} ta test) {medal}".rstrip())
    return "\n".join(lines)


def bar(p, width=5):
    full = round(p / 100 * width)
    return "🟩" * full + "⬜️" * (width - full)
