@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
python bot.py
echo.
echo Bot toxtadi. Xato bolsa, shu oynani skrinshot qilib yuboring.
pause
