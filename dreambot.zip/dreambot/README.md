# Science Pro — mock exam reyting boti (Dream School)

Mavzulashgan mock examlar: javoblarni qabul qiladi, tekshiradi, kanalga reyting va mavzular tahlilini joylaydi, har bir o'quvchiga shaxsiy hisobot yuboradi.

## 1. Botni yaratish (2 daqiqa)
1. Telegram'da **@BotFather** → `/newbot` → nom: *Science Pro*, username: masalan `science_pro_mock_bot`.
2. Bergan **tokenni** saqlab qo'ying.
3. Botni **@ibnsino_tabiiy** kanaliga **admin** qilib qo'shing ("Post messages" ruxsati yetarli).
4. O'z Telegram ID raqamingizni bilish uchun **@userinfobot** ga yozing.

## 2. Ishga tushirish
Faqat Python 3.8+ kerak, boshqa hech narsa o'rnatilmaydi.
```bash
python bot.py
```
Birinchi marta token va ID raqamingizni so'raydi va `.env` fayliga saqlaydi.

**Android telefonda (Termux):**
```bash
pkg update -y && pkg install -y python unzip
termux-setup-storage
cd ~ && unzip -o ~/storage/downloads/dreambot.zip && cd dreambot
python bot.py
```
Bot doimiy ishlashi uchun uni serverda (VPS, PythonAnywhere, Railway va h.k.) ishga tushiring. Kompyuteringizda ishlatsangiz, kompyuter o'chganda bot ham to'xtaydi.

## 3. Ustoz uchun ish tartibi
**Test yaratish** — botga bitta xabarda 3 qator:
```
/yangi Mock Exam 3
dacabbccdabadbabcdbcdcbcddccaa
1-10:Biologiya, 11-20:Kimyo, 21-30:Fizika
```
Kalitni `1d2a3c...` ko'rinishida ham yozish mumkin. Mavzular istalgancha bo'lishi mumkin (masalan, `1-5:Hujayra, 6-10:Genetika, ...`), faqat har bir savol biror mavzuga tushishi shart.

| Buyruq | Vazifasi |
|---|---|
| `/elon KOD` | Testni kanalga e'lon qiladi |
| `/holat` yoki `/holat KOD` | Nechta o'quvchi javob yuborgani |
| `/yakunla KOD` | Testni yopadi, kanalga reyting + mavzular tahlili + eng qiyin savollar + kalitni joylaydi, har bir o'quvchiga shaxsiy tahlil yuboradi |
| `/umumiy` | Barcha testlar bo'yicha umumiy reytingni kanalga joylaydi |

## 4. O'quvchi uchun
- `/start` → ism-familiya kiritadi (bir marta).
- Javob: `KOD*abcdabcd...` yoki `KOD*1a2b3c...` (`#` ham bo'ladi). Har bir testga bir marta.
- `/natijam` — barcha testlardagi natijalari va qaysi mavzu sust ekani.
- `/reyting` — umumiy reyting.

Natija test **yakunlangandan keyin** ko'rsatiladi — shunda javoblar boshqalarga tarqalmaydi.

Ma'lumotlar `dreambot.db` faylida saqlanadi — vaqti-vaqti bilan nusxasini oling.

## 5. Mini ilova (reyting)
Bot ichidagi **📊 Reyting** tugmasi: Mock exam va Mavzulashgan test reytinglari, har bir test bo'yicha mavzular tahlili, o'quvchining shaxsiy natijalari.

- Mock exam: `/yangi ...`, mavzulashgan test: `/mavzu ...` (format bir xil, 3 qator)
- Har `/yakunla` dan keyin ma'lumotlar mini ilovaga avtomatik yuklanadi. Qo'lda yangilash: `/nashr`

**Bir martalik sozlash (GitHub Pages, bepul):**
1. github.com da akkaunt oching.
2. **New repository** → nomi `sciencepro` → **Public** → Create.
3. **uploading an existing file** → `miniapp` papkasidagi `index.html` va `data.json` ni yuklang → Commit.
4. Repo → **Settings → Pages** → Branch: `main` → Save.
5. Profil → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate**:
   Repository access: *Only select* → `sciencepro`; Permissions → **Contents: Read and write** → Generate. Tokenni nusxa oling.
6. Botni to'xtating, **sozlash.bat** ni ishga tushiring, so'ralganlarni kiriting, keyin **start.bat**.

Mini ilova ko'rinishini o'zgartirish: GitHub'da `index.html` ni tahrirlang (yoki Claude'dan so'rang).
