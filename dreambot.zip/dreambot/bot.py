"""
Science Pro — mavzulashgan mock exam reyting boti (Dream School).
Hech qanday qo'shimcha kutubxona kerak emas: faqat Python 3.8+.
Ishga tushirish: python bot.py   (sozlamalar .env faylida)
"""
import base64
import html
import json
import threading
import os
import time
import urllib.error
import urllib.request

import core


def load_env(path=None):
    path = path or os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


load_env()
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
CHANNEL = os.environ.get("CHANNEL_ID", "@ibnsino_tabiiy")
ADMINS = {int(x) for x in os.environ.get("ADMIN_IDS", "").replace(" ", "").split(",") if x.strip()}
DB_PATH = os.environ.get("DB_PATH") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "dreambot.db")

db = core.DB(DB_PATH)
waiting_name = set()
BOT_USERNAME = ""
WEBAPP_URL = os.environ.get("WEBAPP_URL", "").strip()
GITHUB_REPO = os.environ.get("GITHUB_REPO", "").strip()
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "").strip()


# ---------------- Telegram API ----------------

def api(method, **params):
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{BOT_TOKEN}/{method}",
        data=json.dumps(params).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=params.get("timeout", 0) + 15) as r:
            res = json.load(r)
    except urllib.error.HTTPError as e:
        res = json.load(e)
    if not res.get("ok"):
        raise RuntimeError(f"{method}: {res.get('description')}")
    return res["result"]


def send(chat_id, text, markup=None):
    extra = {"reply_markup": markup} if markup else {}
    return api("sendMessage", chat_id=chat_id, text=text, parse_mode="HTML",
               disable_web_page_preview=True, **extra)


def app_button(text="📊 Reytingni ochish"):
    """Mini ilovani ochuvchi tugma (WEBAPP_URL sozlangan bo'lsa)."""
    if not WEBAPP_URL:
        return None
    return {"inline_keyboard": [[{"text": text, "web_app": {"url": WEBAPP_URL}}]]}


# ---------------- Mini ilova ma'lumotlari (GitHub) ----------------

def github_push(path, data: bytes):
    url = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{path}"
    headers = {"Authorization": f"Bearer {GITHUB_TOKEN}", "Accept": "application/vnd.github+json",
               "User-Agent": "sciencepro-bot"}
    sha = None
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=20) as r:
            sha = json.load(r).get("sha")
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise RuntimeError(f"GitHub: {e.code} {e.read()[:200]!r}")
    body = {"message": "Natijalar yangilandi", "content": base64.b64encode(data).decode()}
    if sha:
        body["sha"] = sha
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method="PUT")
    try:
        urllib.request.urlopen(req, timeout=30).close()
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"GitHub: {e.code} {e.read()[:200]!r}")


def publish(notify=None):
    """data.json ni yangilab GitHub'ga yuklaydi. Sozlanmagan bo'lsa jim o'tadi."""
    data = json.dumps(db.export_data(), ensure_ascii=False, separators=(",", ":")).encode()
    local = os.path.join(os.path.dirname(os.path.abspath(__file__)), "miniapp", "data.json")
    try:
        os.makedirs(os.path.dirname(local), exist_ok=True)
        open(local, "wb").write(data)
    except OSError:
        pass
    if not (GITHUB_REPO and GITHUB_TOKEN):
        return

    def run():
        try:
            github_push("data.json", data)
            if notify:
                send(notify, "📊 Mini ilova yangilandi (1–2 daqiqada ko'rinadi).")
        except Exception as e:
            print("GitHub'ga yuklashda xato:", e)
            if notify:
                send(notify, f"❗️ Mini ilovani yangilab bo'lmadi: {html.escape(str(e))[:300]}")
    threading.Thread(target=run, daemon=True).start()


# ---------------- Buyruqlar ----------------

HELP_STUDENT = ("📌 <b>Javob yuborish:</b>\n<code>KOD*abcdabcd...</code>\n"
                "yoki <code>KOD*1a2b3c4d...</code>\n\n"
                "/natijam — natijalaringiz va mavzular tahlili\n"
                "/reyting — reyting (mini ilova)\n"
                "/ism — ismni o'zgartirish")

HELP_ADMIN = ("🛠 <b>Ustoz buyruqlari:</b>\n"
              "/yangi — mock exam yaratish (3 qator: nomi, kalit, mavzular)\n"
              "/mavzu — mavzulashgan test yaratish (xuddi shunday 3 qator)\n"
              "/elon KOD — testni kanalga e'lon qilish\n"
              "/holat [KOD] — nechta javob kelgani\n"
              "/yakunla KOD — yakunlash, natijalarni kanalga va o'quvchilarga yuborish\n"
              "/umumiy — umumiy reytingni kanalga joylash\n"
              "/nashr — mini ilova ma'lumotlarini qayta yangilash")


def announce_text(t):
    summary = core.topic_breakdown(t["topics"], [True] * len(t["key"]))
    label = core.KINDS.get(t.get("kind") or "mock", "Test")
    return (f"📝📝 <b>{html.escape(t['title'])}</b> boshlandi!\n<i>{label}</i>\n\n"
            f"Savollar soni: {len(t['key'])} ta\n"
            + "\n".join(f"• {html.escape(tp)}: {n} ta" for tp, (_, n) in summary.items())
            + f"\n\nTest kodi: <code>{t['code']}</code>\n\n"
            f"Javoblarni @{BOT_USERNAME} ga yuboring:\n<code>{t['code']}*abcdabcd...</code>\n"
            f"yoki\n<code>{t['code']}*1a2b3c4d...</code>\n\n"
            "☝️ Har bir o'quvchi faqat bir marta javob yuboradi.")


def cmd_start(uid, args):
    name = db.name(uid)
    if name:
        send(uid, f"Assalomu alaykum, <b>{html.escape(name)}</b>!\n\n" + HELP_STUDENT)
    else:
        waiting_name.add(uid)
        send(uid, "Assalomu alaykum! <b>Science Pro</b> botiga xush kelibsiz.\n\n"
                  "Reytingda ko'rinishi uchun <b>ism va familiyangizni</b> yozing:\n"
                  "<i>Masalan: Botirova Shukronaxon</i>")


def cmd_ism(uid, args):
    waiting_name.add(uid)
    send(uid, "Yangi ism va familiyangizni yozing:")


def cmd_natijam(uid, args):
    send(uid, core.format_history(db.name(uid) or "Siz", db.student_history(uid)))


def cmd_reyting(uid, args):
    btn = app_button()
    if btn:
        send(uid, "📊 Mock exam va mavzulashgan testlar reytingi, shaxsiy natijalaringiz — mini ilovada:", btn)
    else:
        send(uid, core.format_overall(db.overall_rating()))


def cmd_yordam(uid, args):
    send(uid, HELP_STUDENT + ("\n\n" + HELP_ADMIN if uid in ADMINS else ""))


def cmd_mavzu(uid, args):
    cmd_yangi(uid, args, kind="mavzu")


def cmd_yangi(uid, args, kind="mock"):
    cmdname = "/mavzu" if kind == "mavzu" else "/yangi"
    lines = [l.strip() for l in args.splitlines() if l.strip()]
    if len(lines) != 3:
        send(uid, f"Format (bitta xabarda 3 qator):\n<code>{cmdname} {'Genetika 1' if kind == 'mavzu' else 'Mock Exam 3'}\nabcdabcd...\n"
                  "1-10:Biologiya, 11-20:Kimyo, 21-30:Fizika</code>")
        return
    try:
        key = core.parse_answers(lines[1])
        if "-" in key:
            raise ValueError("Kalitda tushib qolgan savol bor")
        topics = core.parse_topics(lines[2], len(key))
    except ValueError as e:
        send(uid, f"❗️ {html.escape(str(e))}")
        return
    code = db.create_test(lines[0], key, topics, kind)
    t = db.test(code)
    send(uid, f"✅ Test yaratildi. Kod: <code>{code}</code>\n\n"
              f"Kanalga e'lon qilish: <code>/elon {code}</code>\n"
              f"Yakunlash: <code>/yakunla {code}</code>\n\nE'lon ko'rinishi:\n\n" + announce_text(t))


def cmd_elon(uid, args):
    t = db.test(args.strip())
    if not t:
        send(uid, "Bunday kodli test yo'q.")
        return
    send(CHANNEL, announce_text(t))
    send(uid, "✅ Kanalga e'lon qilindi.")


def cmd_holat(uid, args):
    code = args.strip()
    if code:
        t = db.test(code)
        send(uid, f"<b>{html.escape(t['title'])}</b>: {len(db.subs(code))} nafar javob yubordi."
             if t else "Bunday kodli test yo'q.")
        return
    tests = db.open_tests()
    send(uid, "Ochiq testlar:\n" + "\n".join(
        f"• <code>{t['code']}</code> — {html.escape(t['title'])} ({len(db.subs(t['code']))} ta javob)"
        for t in tests) if tests else "Ochiq test yo'q.")


def cmd_yakunla(uid, args):
    code = args.strip()
    t = db.test(code)
    if not t:
        send(uid, "Bunday kodli test yo'q.")
        return
    if not t["open"]:
        send(uid, "Bu test allaqachon yakunlangan.")
        return
    db.close_test(code)
    t, rows, topic_tot, q_correct = db.test_report(code)
    send(CHANNEL, core.format_channel_report(t, rows, topic_tot, q_correct))
    sent, prev, place = 0, None, 0
    for i, r in enumerate(rows):
        if r["score"] != prev:
            place, prev = i + 1, r["score"]
        try:
            send(r["user_id"], core.format_personal_report(t, r, place, len(rows)))
            sent += 1
        except Exception:
            pass  # o'quvchi botni bloklagan bo'lishi mumkin
        time.sleep(0.05)
    send(uid, f"✅ Natijalar kanalga joylandi. {sent}/{len(rows)} o'quvchiga shaxsiy tahlil yuborildi.")
    publish(notify=uid)


def cmd_nashr(uid, args):
    if not (GITHUB_REPO and GITHUB_TOKEN):
        send(uid, "Mini ilova hali sozlanmagan (sozlash.bat ni ishga tushiring).")
        return
    publish(notify=uid)


def cmd_umumiy(uid, args):
    send(CHANNEL, core.format_overall(db.overall_rating()))
    send(uid, "✅ Umumiy reyting kanalga joylandi.")


STUDENT_CMDS = {"start": cmd_start, "ism": cmd_ism, "natijam": cmd_natijam,
                "reyting": cmd_reyting, "yordam": cmd_yordam, "help": cmd_yordam}
ADMIN_CMDS = {"yangi": cmd_yangi, "mavzu": cmd_mavzu, "nashr": cmd_nashr, "elon": cmd_elon, "holat": cmd_holat,
              "yakunla": cmd_yakunla, "umumiy": cmd_umumiy}


def handle_text(uid, text):
    if text.startswith("/"):
        head, _, args = text.partition(" ") if " " in text.split("\n", 1)[0] else text.partition("\n")
        cmd = head[1:].split("@")[0].lower()
        if cmd in STUDENT_CMDS:
            if cmd not in ("ism", "start"):
                waiting_name.discard(uid)
            STUDENT_CMDS[cmd](uid, args)
        elif cmd in ADMIN_CMDS and uid in ADMINS:
            ADMIN_CMDS[cmd](uid, args)
        else:
            send(uid, HELP_STUDENT)
        return

    if uid in waiting_name:
        name = " ".join(text.split())[:60]
        if len(name) < 3:
            send(uid, "Iltimos, ism va familiyangizni to'g'ri yozing.")
            return
        db.set_name(uid, name)
        waiting_name.discard(uid)
        send(uid, f"✅ Saqlandi: <b>{html.escape(name)}</b>\n\n" + HELP_STUDENT)
        return

    try:
        parsed = core.parse_submission(text)
    except ValueError:
        send(uid, "❗️ Javoblar faqat a, b, c, d, e harflaridan iborat bo'lishi kerak.")
        return
    if not parsed:
        send(uid, HELP_STUDENT)
        return
    if not db.name(uid):
        waiting_name.add(uid)
        send(uid, "Avval ism va familiyangizni yozing, keyin javoblarni qayta yuboring:")
        return

    code, answers = parsed
    res = db.submit(code, uid, answers)
    msgs = {
        "ok": f"✅ Javoblaringiz qabul qilindi ({len(answers)} ta).\n"
              "Natija va mavzular bo'yicha tahlil test yakunlangach yuboriladi.",
        "no_test": "❗️ Bunday kodli test topilmadi. Kodni tekshiring.",
        "closed": "⛔️ Bu test yakunlangan, javob qabul qilinmaydi.",
        "dup": "Siz bu testga allaqachon javob yuborgansiz. Faqat bir marta yuborish mumkin.",
    }
    send(uid, msgs[res] if isinstance(res, str) else
         f"❗️ Javoblar soni noto'g'ri: {len(answers)} ta yubordingiz, kerak — {res[1]} ta.")


# ---------------- Asosiy sikl ----------------

def main():
    global BOT_USERNAME
    global BOT_TOKEN, ADMINS
    if not BOT_TOKEN:
        print("Birinchi sozlash.")
        BOT_TOKEN = input("BotFather bergan tokenni kiriting: ").strip()
        admin = input("@userinfobot bergan ID raqamingiz: ").strip()
        ADMINS = {int(x) for x in admin.replace(" ", "").split(",") if x}
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"), "w", encoding="utf-8") as f:
            f.write(f"BOT_TOKEN={BOT_TOKEN}\nCHANNEL_ID={CHANNEL}\nADMIN_IDS={admin}\n")
        print("✅ Saqlandi (.env). Keyingi safar so'ralmaydi.")
    BOT_USERNAME = api("getMe")["username"]
    print(f"✅ @{BOT_USERNAME} ishga tushdi. Ustozlar: {ADMINS or 'belgilanmagan!'}")
    if WEBAPP_URL:
        try:
            api("setChatMenuButton", menu_button={"type": "web_app", "text": "📊 Reyting",
                                                  "web_app": {"url": WEBAPP_URL}})
            print("📊 Mini ilova tugmasi o'rnatildi:", WEBAPP_URL)
        except Exception as e:
            print("Mini ilova tugmasini o'rnatib bo'lmadi:", e)
        publish()
    print("To'xtatish uchun Ctrl+C")
    offset = 0
    while True:
        try:
            updates = api("getUpdates", offset=offset, timeout=30, allowed_updates=["message"])
        except Exception as e:
            print("Ulanishda xato, 5 soniyadan keyin qayta urinish:", e)
            time.sleep(5)
            continue
        for u in updates:
            offset = u["update_id"] + 1
            m = u.get("message")
            if not m or m["chat"]["type"] != "private" or "text" not in m:
                continue
            try:
                handle_text(m["from"]["id"], m["text"])
            except Exception as e:
                print("Xabarni qayta ishlashda xato:", e)


def setup_webapp():
    """Mini ilova sozlamalarini so'rab .env ga yozadi (sozlash.bat)."""
    print("Mini ilovani sozlash. Har biriga javob yozib Enter bosing.\n")
    user = input("GitHub username (masalan: zuhriddin582): ").strip()
    repo = input("Repozitoriya nomi [sciencepro]: ").strip() or "sciencepro"
    token = input("GitHub token (github_pat_... yoki ghp_...): ").strip()
    url = f"https://{user.lower()}.github.io/{repo}/"
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    lines = []
    if os.path.exists(path):
        lines = [l for l in open(path, encoding="utf-8").read().splitlines()
                 if not l.startswith(("WEBAPP_URL=", "GITHUB_REPO=", "GITHUB_TOKEN="))]
    lines += [f"WEBAPP_URL={url}", f"GITHUB_REPO={user}/{repo}", f"GITHUB_TOKEN={token}"]
    open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print(f"\n✅ Saqlandi. Mini ilova manzili: {url}")
    print("Endi botni qayta ishga tushiring (start.bat).")


if __name__ == "__main__":
    import sys
    if "--sozla" in sys.argv:
        setup_webapp()
    else:
        main()
